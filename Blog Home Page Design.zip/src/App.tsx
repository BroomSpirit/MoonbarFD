import { useState } from "react";
import { Header } from "./components/Header";
import { DropdownMenu } from "./components/DropdownMenu";
import { HomePage } from "./components/HomePage";
import { ExplorePage } from "./components/ExplorePage";
import { ArticleDetailPage } from "./components/ArticleDetailPage";
import { ProfilePage } from "./components/ProfilePage";
import { ReadingListPage } from "./components/ReadingListPage";
import { SavedListPage } from "./components/SavedListPage";
import { SettingsPage } from "./components/SettingsPage";
import { CreateArticlePage } from "./components/CreateArticlePage";
import { DraftsPage } from "./components/DraftsPage";
import { PublishedPage } from "./components/PublishedPage";
import { WelcomePage } from "./components/WelcomePage";
import bgImage from "figma:asset/28e5f0bf3687b474bb50cab1b440865b3e9a0792.png";

type Page = "home" | "explore" | "profile" | "settings" | "create" | "article" | "reading-list" | "saved-list" | "drafts" | "published";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [selectedArticleId, setSelectedArticleId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [publishedArticles, setPublishedArticles] = useState<any[]>([]);

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const handleArticleClick = (articleId: number) => {
    setSelectedArticleId(articleId);
    setCurrentPage("article");
  };

  const handleBackFromArticle = () => {
    setCurrentPage("explore");
  };

  const handleNavigateToList = (listType: "reading" | "saved") => {
    setCurrentPage(listType === "reading" ? "reading-list" : "saved-list");
  };

  const handleBackToProfile = () => {
    setCurrentPage("profile");
  };

  const handlePublish = (article: any) => {
    setPublishedArticles([article, ...publishedArticles]);
    setCurrentPage("published");
  };

  const handleSaveDraft = (draft: any) => {
    // In real app, would save to drafts list
    console.log("Draft saved:", draft);
  };

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      setIsLoggedIn(false);
      setCurrentPage("home");
      setSearchQuery("");
      alert("Logged out successfully!");
    }
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage("explore");
  };

  // Determine if search should be shown
  const showSearch = !["profile", "settings", "create", "drafts", "published"].includes(currentPage);

  // Show welcome page if not logged in
  if (!isLoggedIn) {
    return <WelcomePage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#F5F1E8]">
      {/* Background with overlay */}
      <div 
        className="fixed inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      />
      
      <div className="relative z-10">
        <Header
          onMenuClick={() => setIsMenuOpen(true)}
          showSearch={showSearch}
          onSearch={handleSearch}
        />
        <DropdownMenu
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          onNavigate={handleNavigate}
        />

        {currentPage === "home" && <HomePage onArticleClick={handleArticleClick} />}
        {currentPage === "explore" && (
          <ExplorePage
            onArticleClick={handleArticleClick}
            searchQuery={searchQuery}
            userPublishedArticles={publishedArticles}
          />
        )}
        {currentPage === "profile" && (
          <ProfilePage onNavigateToList={handleNavigateToList} />
        )}
        {currentPage === "reading-list" && (
          <ReadingListPage
            onBack={handleBackToProfile}
            onArticleClick={handleArticleClick}
          />
        )}
        {currentPage === "saved-list" && (
          <SavedListPage
            onBack={handleBackToProfile}
            onArticleClick={handleArticleClick}
          />
        )}
        {currentPage === "article" && selectedArticleId && (
          <ArticleDetailPage
            articleId={selectedArticleId}
            onBack={handleBackFromArticle}
          />
        )}
        {currentPage === "settings" && (
          <SettingsPage onLogout={handleLogout} />
        )}
        {currentPage === "create" && (
          <CreateArticlePage
            onPublish={handlePublish}
            onSaveDraft={handleSaveDraft}
          />
        )}
        {currentPage === "drafts" && (
          <DraftsPage
            onBack={() => setCurrentPage("home")}
            onEditDraft={(id) => setCurrentPage("create")}
          />
        )}
        {currentPage === "published" && (
          <PublishedPage
            onBack={() => setCurrentPage("home")}
            onArticleClick={handleArticleClick}
          />
        )}
      </div>
    </div>
  );
}