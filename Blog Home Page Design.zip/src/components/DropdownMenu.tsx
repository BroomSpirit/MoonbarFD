import { Home, Compass, User, Settings, PlusCircle, X, FileText, CheckCircle, Edit, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";

interface DropdownMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
}

const menuItems = [
  { icon: Home, label: "Home", href: "home" },
  { icon: Compass, label: "Explore", href: "explore" },
  { icon: User, label: "Profile", href: "profile" },
  { icon: Settings, label: "Settings", href: "settings" },
  {
    icon: Edit,
    label: "Write",
    href: "write",
    submenu: [
      { label: "Create New", href: "create" },
      { label: "Drafts", href: "drafts" },
      { label: "Published", href: "published" },
    ],
  },
];

export function DropdownMenu({ isOpen, onClose, onNavigate }: DropdownMenuProps) {
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);

  const toggleSubmenu = (label: string) => {
    setExpandedMenu(expandedMenu === label ? null : label);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#294713]/20 z-40 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed left-0 top-0 bottom-0 w-72 bg-white z-50 shadow-2xl"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-[#294713] text-xl">Menu</h2>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-[#BBA767]/10 rounded-xl transition-colors"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5 text-[#294713]" />
                </button>
              </div>
              
              <nav className="space-y-2">
                {menuItems.map((item, index) => (
                  <motion.button
                    key={item.label}
                    onClick={() => {
                      if (item.submenu) {
                        toggleSubmenu(item.label);
                      } else {
                        onNavigate(item.label.toLowerCase());
                        onClose();
                      }
                    }}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-xl hover:bg-[#7CA74B]/10 text-[#294713] transition-colors group"
                  >
                    <item.icon className="w-5 h-5 text-[#7CA74B]" />
                    <span>{item.label}</span>
                  </motion.button>
                ))}
              </nav>

              {expandedMenu && (
                <nav className="space-y-2 mt-2">
                  {menuItems.find((item) => item.label === expandedMenu)?.submenu?.map((subitem) => (
                    <motion.button
                      key={subitem.label}
                      onClick={() => {
                        onNavigate(subitem.href);
                        onClose();
                      }}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 }}
                      className="w-full flex items-center gap-4 px-4 py-3 rounded-xl hover:bg-[#7CA74B]/10 text-[#294713] transition-colors group"
                    >
                      <FileText className="w-5 h-5 text-[#7CA74B]" />
                      <span>{subitem.label}</span>
                    </motion.button>
                  ))}
                </nav>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}