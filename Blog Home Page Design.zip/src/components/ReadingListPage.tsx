import { useState } from "react";
import { ArrowLeft, Trash2, BookOpen } from "lucide-react";

interface ReadingArticle {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  readTime: string;
  category: string;
  status: string;
  progress: number;
}

// Mock data - expanded version
const readingArticles: ReadingArticle[] = [
  {
    id: 1,
    title: "The Future of Artificial Intelligence in Healthcare",
    excerpt: "Exploring how AI is revolutionizing medical diagnosis and patient care in modern healthcare systems.",
    image: "https://images.unsplash.com/photo-1623715537851-8bc15aa8c145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlfGVufDF8fHx8MTc2MzA0OTc5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Sarah Johnson",
    readTime: "8 min read",
    category: "Technology",
    status: "reading",
    progress: 65,
  },
  {
    id: 2,
    title: "Building Scalable Web Applications with Modern Frameworks",
    excerpt: "A comprehensive guide to creating robust and scalable web applications using the latest technologies.",
    image: "https://images.unsplash.com/photo-1519217651866-847339e674d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjMwMTYzNDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Michael Chen",
    readTime: "12 min read",
    category: "Technology",
    status: "completed",
    progress: 100,
  },
  {
    id: 3,
    title: "Understanding Quantum Physics for Beginners",
    excerpt: "A beginner-friendly introduction to the fascinating world of quantum mechanics and its implications.",
    image: "https://images.unsplash.com/photo-1617634667039-8e4cb277ab46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmUlMjBsYW5kc2NhcGV8ZW58MXx8fHwxNzYzMTM1MDM3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Dr. Emma Watson",
    readTime: "15 min read",
    category: "Science",
    status: "reading",
    progress: 30,
  },
  {
    id: 4,
    title: "The Complete Guide to Mindful Living",
    excerpt: "Transform your daily routine with mindfulness practices that promote well-being and happiness.",
    image: "https://images.unsplash.com/photo-1610060616036-09bd2c69e8d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWZlc3R5bGUlMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjMxNDI3ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Maria Garcia",
    readTime: "6 min read",
    category: "Lifestyle",
    status: "completed",
    progress: 100,
  },
];

interface ReadingListPageProps {
  onBack: () => void;
  onArticleClick: (articleId: number) => void;
}

export function ReadingListPage({ onBack, onArticleClick }: ReadingListPageProps) {
  const [articles, setArticles] = useState<ReadingArticle[]>(readingArticles);

  const handleRemove = (articleId: number) => {
    setArticles(articles.filter((article) => article.id !== articleId));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#7CA74B] hover:text-[#294713] transition-colors mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Profile</span>
      </button>

      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-[#7CA74B]/10 rounded-xl">
          <BookOpen className="w-6 h-6 text-[#7CA74B]" />
        </div>
        <div>
          <h1 className="text-[#294713]">Reading List</h1>
          <p className="text-[#897684]">{articles.length} articles</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article) => (
          <div
            key={article.id}
            className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group relative"
            style={{ aspectRatio: "3/4" }}
          >
            {/* Remove Button */}
            <button
              onClick={() => handleRemove(article.id)}
              className="absolute top-3 right-3 z-10 p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-red-500 hover:text-white transition-colors opacity-0 group-hover:opacity-100"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <div
              onClick={() => onArticleClick(article.id)}
              className="cursor-pointer h-full flex flex-col"
            >
              <div className="relative h-[55%] overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className="px-3 py-1 bg-[#7CA74B] text-white rounded-full text-xs uppercase tracking-wide">
                    {article.category}
                  </span>
                  <span
                    className={`px-3 py-1 rounded-full text-xs uppercase tracking-wide ${
                      article.status === "completed"
                        ? "bg-[#57C952] text-white"
                        : "bg-[#BBA767] text-white"
                    }`}
                  >
                    {article.status === "completed" ? "Completed" : "Reading"}
                  </span>
                </div>
              </div>

              <div className="p-5 h-[45%] flex flex-col">
                <h3 className="text-[#294713] mb-2 line-clamp-2 group-hover:text-[#7CA74B] transition-colors">
                  {article.title}
                </h3>

                <p className="text-[#897684] text-sm flex-1 line-clamp-2 mb-3">
                  {article.excerpt}
                </p>

                {/* Progress Bar */}
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-[#897684]">Progress</span>
                    <span className="text-xs text-[#7CA74B]">{article.progress}%</span>
                  </div>
                  <div className="h-2 bg-[#897684]/20 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#7CA74B] rounded-full transition-all"
                      style={{ width: `${article.progress}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-[#897684]">
                  <span>{article.author}</span>
                  <span>{article.readTime}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {articles.length === 0 && (
        <div className="text-center py-20">
          <BookOpen className="w-16 h-16 text-[#897684]/30 mx-auto mb-4" />
          <p className="text-[#897684]">Your reading list is empty</p>
        </div>
      )}
    </div>
  );
}
