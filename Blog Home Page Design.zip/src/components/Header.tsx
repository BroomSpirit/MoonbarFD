import { Search, Menu } from "lucide-react";
import { useState } from "react";

interface HeaderProps {
  onMenuClick: () => void;
  showSearch?: boolean;
  onSearch?: (query: string) => void;
}

export function Header({ onMenuClick, showSearch = true, onSearch }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md px-4 py-4 shadow-sm border-b border-[#BBA767]/20">
      <div className="flex items-center gap-4 max-w-7xl mx-auto">
        <button
          onClick={onMenuClick}
          className="p-2 hover:bg-[#BBA767]/10 rounded-xl transition-colors"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6 text-[#294713]" />
        </button>
        
        {showSearch && (
          <form onSubmit={handleSearch} className="flex-1 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search articles..."
              className="w-full px-4 py-2.5 pl-10 rounded-full bg-[#BBA767]/5 border border-[#BBA767]/20 text-[#294713] placeholder:text-[#897684]/60 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] focus:border-transparent"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#897684]/60" />
          </form>
        )}
      </div>
    </header>
  );
}