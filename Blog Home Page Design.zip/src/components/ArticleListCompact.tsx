interface CompactArticle {
  id: number;
  title: string;
  status?: string;
  progress?: number;
  savedDate?: string;
}

interface ArticleListCompactProps {
  articles: CompactArticle[];
  type: "reading" | "saved";
}

export function ArticleListCompact({ articles, type }: ArticleListCompactProps) {
  return (
    <div className="space-y-3">
      {articles.slice(0, 3).map((article) => (
        <div
          key={article.id}
          className="p-3 bg-[#F5F1E8] rounded-lg hover:bg-[#BBA767]/10 transition-colors"
        >
          <p className="text-sm text-[#294713] line-clamp-2 mb-2">{article.title}</p>
          {type === "reading" && article.progress !== undefined && (
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-[#897684]/20 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#7CA74B] rounded-full transition-all"
                  style={{ width: `${article.progress}%` }}
                />
              </div>
              <span className="text-xs text-[#897684]">{article.progress}%</span>
            </div>
          )}
          {type === "saved" && article.savedDate && (
            <p className="text-xs text-[#897684]">{article.savedDate}</p>
          )}
        </div>
      ))}
      <p className="text-xs text-center text-[#897684] pt-2">
        Click to view all {articles.length} articles
      </p>
    </div>
  );
}
