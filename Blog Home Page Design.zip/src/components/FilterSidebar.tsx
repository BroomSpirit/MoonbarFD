import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface FilterCategory {
  id: string;
  name: string;
  subcategories: string[];
}

interface FilterSidebarProps {
  categories: FilterCategory[];
  selectedCategory: string | null;
  selectedSubcategory: string | null;
  onCategorySelect: (category: string | null, subcategory: string | null) => void;
}

export function FilterSidebar({
  categories,
  selectedCategory,
  selectedSubcategory,
  onCategorySelect,
}: FilterSidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  return (
    <aside className="w-full h-fit bg-white rounded-2xl shadow-sm p-6 sticky top-24">
      <h2 className="text-[#294713] mb-6">Filters</h2>
      
      <div className="space-y-2">
        {/* ALL option */}
        <button
          onClick={() => onCategorySelect(null, null)}
          className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors text-left ${
            selectedCategory === null
              ? "bg-[#7CA74B] text-white"
              : "hover:bg-[#BBA767]/10 text-[#294713]"
          }`}
        >
          <span>ALL</span>
        </button>

        {categories.map((category) => {
          const isExpanded = expandedCategories.includes(category.id);
          const isCategorySelected = selectedCategory === category.name && !selectedSubcategory;
          
          return (
            <div key={category.id}>
              <div className="flex items-stretch gap-1">
                <button
                  onClick={() => onCategorySelect(category.name, null)}
                  className={`flex-1 flex items-center px-4 py-3 rounded-l-xl transition-colors text-left ${
                    isCategorySelected
                      ? "bg-[#7CA74B] text-white"
                      : selectedCategory === category.name && selectedSubcategory
                      ? "bg-[#7CA74B]/20 text-[#294713]"
                      : "hover:bg-[#BBA767]/10 text-[#294713]"
                  }`}
                >
                  <span>{category.name}</span>
                </button>
                <button
                  onClick={() => toggleCategory(category.id)}
                  className={`px-3 py-3 rounded-r-xl transition-colors ${
                    isCategorySelected
                      ? "bg-[#7CA74B] text-white"
                      : selectedCategory === category.name && selectedSubcategory
                      ? "bg-[#7CA74B]/20 text-[#294713]"
                      : "hover:bg-[#BBA767]/10 text-[#897684]/60"
                  }`}
                >
                  {isExpanded ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>
              </div>
              
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="pl-4 pt-1 pb-2 space-y-1">
                      {category.subcategories.map((sub) => {
                        const isSelected = selectedCategory === category.name && selectedSubcategory === sub;
                        
                        return (
                          <button
                            key={sub}
                            onClick={() => onCategorySelect(category.name, sub)}
                            className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                              isSelected
                                ? "bg-[#7CA74B] text-white"
                                : "text-[#897684] hover:bg-[#BBA767]/5 hover:text-[#294713]"
                            }`}
                          >
                            {sub}
                          </button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </aside>
  );
}