import { useState } from "react";
import { Bell, Mail, Lock, Trash2, LogOut, ChevronRight } from "lucide-react";

interface SettingsPageProps {
  onLogout: () => void;
}

export function SettingsPage({ onLogout }: SettingsPageProps) {
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [articleRecommendations, setArticleRecommendations] = useState(true);
  const [weeklyDigest, setWeeklyDigest] = useState(false);
  
  const [showEmailChange, setShowEmailChange] = useState(false);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [showDeleteAccount, setShowDeleteAccount] = useState(false);

  const [newEmail, setNewEmail] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleEmailChange = () => {
    // Handle email change
    alert("Email updated successfully!");
    setShowEmailChange(false);
    setNewEmail("");
  };

  const handlePasswordChange = () => {
    if (newPassword !== confirmPassword) {
      alert("Passwords don't match!");
      return;
    }
    alert("Password updated successfully!");
    setShowPasswordChange(false);
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const handleDeleteAccount = () => {
    if (window.confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      alert("Account deletion initiated. You will receive a confirmation email.");
      setShowDeleteAccount(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-[#294713] mb-8">Settings</h1>

      <div className="space-y-6">
        {/* Notifications Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-[#7CA74B]/10 rounded-lg">
              <Bell className="w-5 h-5 text-[#7CA74B]" />
            </div>
            <h2 className="text-[#294713]">Notification Preferences</h2>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-[#BBA767]/10">
              <div>
                <p className="text-[#294713]">Email Notifications</p>
                <p className="text-sm text-[#897684]">Receive notifications via email</p>
              </div>
              <button
                onClick={() => setEmailNotifications(!emailNotifications)}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  emailNotifications ? "bg-[#7CA74B]" : "bg-[#897684]/30"
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                    emailNotifications ? "translate-x-7" : ""
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-[#BBA767]/10">
              <div>
                <p className="text-[#294713]">Push Notifications</p>
                <p className="text-sm text-[#897684]">Receive push notifications</p>
              </div>
              <button
                onClick={() => setPushNotifications(!pushNotifications)}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  pushNotifications ? "bg-[#7CA74B]" : "bg-[#897684]/30"
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                    pushNotifications ? "translate-x-7" : ""
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-[#BBA767]/10">
              <div>
                <p className="text-[#294713]">Article Recommendations</p>
                <p className="text-sm text-[#897684]">Get personalized article suggestions</p>
              </div>
              <button
                onClick={() => setArticleRecommendations(!articleRecommendations)}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  articleRecommendations ? "bg-[#7CA74B]" : "bg-[#897684]/30"
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                    articleRecommendations ? "translate-x-7" : ""
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between py-3">
              <div>
                <p className="text-[#294713]">Weekly Digest</p>
                <p className="text-sm text-[#897684]">Receive weekly summary of top articles</p>
              </div>
              <button
                onClick={() => setWeeklyDigest(!weeklyDigest)}
                className={`relative w-14 h-7 rounded-full transition-colors ${
                  weeklyDigest ? "bg-[#7CA74B]" : "bg-[#897684]/30"
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                    weeklyDigest ? "translate-x-7" : ""
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Email Change Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-[#BBA767]/10 rounded-lg">
              <Mail className="w-5 h-5 text-[#BBA767]" />
            </div>
            <h2 className="text-[#294713]">Email Address</h2>
          </div>

          {!showEmailChange ? (
            <button
              onClick={() => setShowEmailChange(true)}
              className="flex items-center justify-between w-full py-3 px-4 rounded-xl hover:bg-[#BBA767]/5 transition-colors group"
            >
              <span className="text-[#897684]">Change email address</span>
              <ChevronRight className="w-5 h-5 text-[#897684] group-hover:text-[#7CA74B]" />
            </button>
          ) : (
            <div className="space-y-4">
              <input
                type="email"
                placeholder="New email address"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
              />
              <div className="flex gap-3">
                <button
                  onClick={handleEmailChange}
                  className="flex-1 px-4 py-2 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors"
                >
                  Update Email
                </button>
                <button
                  onClick={() => setShowEmailChange(false)}
                  className="flex-1 px-4 py-2 bg-[#897684]/10 text-[#897684] rounded-xl hover:bg-[#897684]/20 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Password Management Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-[#57C952]/10 rounded-lg">
              <Lock className="w-5 h-5 text-[#57C952]" />
            </div>
            <h2 className="text-[#294713]">Password Management</h2>
          </div>

          {!showPasswordChange ? (
            <button
              onClick={() => setShowPasswordChange(true)}
              className="flex items-center justify-between w-full py-3 px-4 rounded-xl hover:bg-[#BBA767]/5 transition-colors group"
            >
              <span className="text-[#897684]">Change password</span>
              <ChevronRight className="w-5 h-5 text-[#897684] group-hover:text-[#7CA74B]" />
            </button>
          ) : (
            <div className="space-y-4">
              <input
                type="password"
                placeholder="Current password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
              />
              <input
                type="password"
                placeholder="New password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
              />
              <input
                type="password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
              />
              <div className="flex gap-3">
                <button
                  onClick={handlePasswordChange}
                  className="flex-1 px-4 py-2 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors"
                >
                  Update Password
                </button>
                <button
                  onClick={() => setShowPasswordChange(false)}
                  className="flex-1 px-4 py-2 bg-[#897684]/10 text-[#897684] rounded-xl hover:bg-[#897684]/20 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Delete Account Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-red-500/10 rounded-lg">
              <Trash2 className="w-5 h-5 text-red-500" />
            </div>
            <h2 className="text-[#294713]">Delete Account</h2>
          </div>

          {!showDeleteAccount ? (
            <button
              onClick={() => setShowDeleteAccount(true)}
              className="flex items-center justify-between w-full py-3 px-4 rounded-xl hover:bg-red-50 transition-colors group"
            >
              <span className="text-[#897684]">Permanently delete your account</span>
              <ChevronRight className="w-5 h-5 text-[#897684] group-hover:text-red-500" />
            </button>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-[#897684]">
                This action cannot be undone. All your articles, saved items, and personal data will be permanently deleted.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={handleDeleteAccount}
                  className="flex-1 px-4 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-colors"
                >
                  Delete My Account
                </button>
                <button
                  onClick={() => setShowDeleteAccount(false)}
                  className="flex-1 px-4 py-2 bg-[#897684]/10 text-[#897684] rounded-xl hover:bg-[#897684]/20 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Logout Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <button
            onClick={onLogout}
            className="flex items-center gap-3 w-full py-3 px-4 rounded-xl hover:bg-[#897684]/5 transition-colors group"
          >
            <div className="p-2 bg-[#897684]/10 rounded-lg group-hover:bg-[#897684]/20 transition-colors">
              <LogOut className="w-5 h-5 text-[#897684]" />
            </div>
            <span className="text-[#294713]">Logout</span>
          </button>
        </div>
      </div>
    </div>
  );
}
