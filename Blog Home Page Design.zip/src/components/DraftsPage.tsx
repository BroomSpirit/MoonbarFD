import { useState } from "react";
import { ArrowLeft, Edit2, Trash2, FileText } from "lucide-react";

interface Draft {
  id: number;
  title: string;
  subtitle: string;
  category: string;
  subcategory: string;
  updatedAt: string;
  wordCount: number;
}

const mockDrafts: Draft[] = [
  {
    id: 1,
    title: "The Rise of Quantum Computing",
    subtitle: "How quantum technology will change everything",
    category: "Technology",
    subcategory: "AI",
    updatedAt: "2025-11-15T10:30:00",
    wordCount: 450,
  },
  {
    id: 2,
    title: "Sustainable Living in 2025",
    subtitle: "",
    category: "Lifestyle",
    subcategory: "Minimalism",
    updatedAt: "2025-11-14T15:20:00",
    wordCount: 320,
  },
];

interface DraftsPageProps {
  onBack: () => void;
  onEditDraft: (draftId: number) => void;
}

export function DraftsPage({ onBack, onEditDraft }: DraftsPageProps) {
  const [drafts, setDrafts] = useState<Draft[]>(mockDrafts);

  const handleDelete = (draftId: number) => {
    if (window.confirm("Are you sure you want to delete this draft?")) {
      setDrafts(drafts.filter((d) => d.id !== draftId));
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#7CA74B] hover:text-[#294713] transition-colors mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back</span>
      </button>

      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-[#BBA767]/10 rounded-xl">
          <FileText className="w-6 h-6 text-[#BBA767]" />
        </div>
        <div>
          <h1 className="text-[#294713]">My Drafts</h1>
          <p className="text-[#897684]">{drafts.length} draft{drafts.length !== 1 ? "s" : ""}</p>
        </div>
      </div>

      <div className="space-y-4">
        {drafts.map((draft) => (
          <div
            key={draft.id}
            className="bg-white rounded-2xl shadow-sm p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="text-[#294713] mb-2">{draft.title}</h3>
                {draft.subtitle && (
                  <p className="text-[#897684] mb-3">{draft.subtitle}</p>
                )}
                <div className="flex items-center gap-4 text-sm text-[#897684]">
                  <span className="px-3 py-1 bg-[#7CA74B]/10 text-[#7CA74B] rounded-full">
                    {draft.category}
                  </span>
                  {draft.subcategory && (
                    <span className="px-3 py-1 bg-[#BBA767]/10 text-[#BBA767] rounded-full">
                      {draft.subcategory}
                    </span>
                  )}
                  <span>{draft.wordCount} words</span>
                  <span>Updated {formatDate(draft.updatedAt)}</span>
                </div>
              </div>

              <div className="flex gap-2 ml-4">
                <button
                  onClick={() => onEditDraft(draft.id)}
                  className="p-2 bg-[#7CA74B]/10 text-[#7CA74B] rounded-xl hover:bg-[#7CA74B] hover:text-white transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(draft.id)}
                  className="p-2 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {drafts.length === 0 && (
          <div className="text-center py-20">
            <FileText className="w-16 h-16 text-[#897684]/30 mx-auto mb-4" />
            <p className="text-[#897684]">No drafts yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
