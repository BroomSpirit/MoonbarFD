import { ArticleCarousel } from "./ArticleCarousel";

const recommendedArticles = [
  {
    id: 1,
    title: "Exploring the Hidden Valleys of Mountain Ranges",
    image: "https://images.unsplash.com/photo-1578592391689-0e3d1a1b52b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZ3xlbnwxfHx8fDE3NjMxMzExNTB8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 2,
    title: "The Art of Sustainable Living in Modern Cities",
    image: "https://images.unsplash.com/photo-1610060616036-09bd2c69e8d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWZlc3R5bGUlMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjMxNDI3ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 3,
    title: "Journey Through Ancient Forest Trails",
    image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb3Jlc3QlMjB0cmVlc3xlbnwxfHx8fDE3NjMwNjA0NDV8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 4,
    title: "Discovering Untouched Beaches Around the World",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMGJlYWNofGVufDF8fHx8MTc2MzEyNDg3OXww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 5,
    title: "Camping Under the Stars: A Complete Guide",
    image: "https://images.unsplash.com/photo-1578645510447-e20b4311e3ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvdXRkb29yJTIwY2FtcGluZ3xlbnwxfHx8fDE3NjMwOTM1MzV8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

const popularArticles = [
  {
    id: 6,
    title: "The Ultimate Guide to Travel Photography",
    image: "https://images.unsplash.com/photo-1528543606781-2f6e6857f318?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzYzMTIzNjEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 7,
    title: "10 Must-Try International Cuisines in 2025",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzYzMTI5NzU3fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 8,
    title: "Morning Rituals for a Productive Day",
    image: "https://images.unsplash.com/photo-1518057111178-44a106bad636?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBtb3JuaW5nfGVufDF8fHx8MTc2MzA3NzE1MHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 9,
    title: "Breathtaking Sunset Destinations You Need to Visit",
    image: "https://images.unsplash.com/photo-1490735891913-40897cdaafd1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjBza3l8ZW58MXx8fHwxNzYzMDgwMDcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 10,
    title: "Urban Exploration: Hidden Gems in Major Cities",
    image: "https://images.unsplash.com/photo-1762530351329-5206c031bb1e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMGNpdHlzY2FwZXxlbnwxfHx8fDE3NjMwNDM1MjF8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

const recentArticles = [
  {
    id: 11,
    title: "Remote Work Revolution: Creating Your Perfect Workspace",
    image: "https://images.unsplash.com/photo-1623715537851-8bc15aa8c145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlfGVufDF8fHx8MTc2MzA0OTc5MHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 12,
    title: "Minimalist Design Trends Transforming Modern Homes",
    image: "https://images.unsplash.com/photo-1528262004378-a108d795029c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwZGVzaWdufGVufDF8fHx8MTc2MzEwMjQ1N3ww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 13,
    title: "Garden Therapy: Growing Your Own Urban Oasis",
    image: "https://images.unsplash.com/photo-1559150182-a7144f7628f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYXJkZW4lMjBmbG93ZXJzfGVufDF8fHx8MTc2MzEwOTk4Mnww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 14,
    title: "The Creative Process: Tips from Industry Professionals",
    image: "https://images.unsplash.com/photo-1519217651866-847339e674d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjMwMTYzNDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 15,
    title: "Majestic Landscapes: Nature Photography Tips",
    image: "https://images.unsplash.com/photo-1617634667039-8e4cb277ab46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmUlMjBsYW5kc2NhcGV8ZW58MXx8fHwxNzYzMTM1MDM3fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

export interface HomePageProps {
  onArticleClick?: (articleId: number) => void;
}

export function HomePage({ onArticleClick }: HomePageProps) {
  const handleCarouselClick = (articleId: number) => {
    if (onArticleClick) {
      onArticleClick(articleId);
    }
  };

  return (
    <main className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      {/* Section Title and Carousel */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-1 h-6 bg-[#7CA74B] rounded-full"></div>
          <h2 className="text-[#294713]">Recommended Blogs</h2>
        </div>
        <ArticleCarousel
          category="RECOMMENDED"
          articles={recommendedArticles}
          onArticleClick={handleCarouselClick}
        />
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-1 h-6 bg-[#57C952] rounded-full"></div>
          <h2 className="text-[#294713]">Popular Blogs</h2>
        </div>
        <ArticleCarousel
          category="POPULAR"
          articles={popularArticles}
          onArticleClick={handleCarouselClick}
        />
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-1 h-6 bg-[#897684] rounded-full"></div>
          <h2 className="text-[#294713]">Recent Blogs</h2>
        </div>
        <ArticleCarousel
          category="RECENT"
          articles={recentArticles}
          onArticleClick={handleCarouselClick}
        />
      </div>
    </main>
  );
}