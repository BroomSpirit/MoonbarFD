import { Clock, User } from "lucide-react";

interface ArticleCardProps {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  readTime: string;
  category: string;
  onClick: () => void;
}

export function ArticleCard({
  title,
  excerpt,
  image,
  author,
  readTime,
  category,
  onClick,
}: ArticleCardProps) {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer group"
      style={{ aspectRatio: "3/4" }}
    >
      <div className="relative h-[55%] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <span className="px-3 py-1 bg-[#7CA74B] text-white rounded-full text-xs uppercase tracking-wide">
            {category}
          </span>
        </div>
      </div>
      
      <div className="p-5 h-[45%] flex flex-col">
        <h3 className="text-[#294713] mb-2 line-clamp-2 group-hover:text-[#7CA74B] transition-colors">
          {title}
        </h3>
        
        <p className="text-[#897684] text-sm flex-1 line-clamp-3 mb-3">
          {excerpt}
        </p>
        
        <div className="flex items-center justify-between text-xs text-[#897684]">
          <div className="flex items-center gap-1">
            <User className="w-3 h-3" />
            <span>{author}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{readTime}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
