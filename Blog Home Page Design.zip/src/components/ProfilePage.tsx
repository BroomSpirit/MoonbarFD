import { useState } from "react";
import { Edit2, BookOpen, Bookmark, Camera } from "lucide-react";
import { ArticleListCompact } from "./ArticleListCompact";

interface ProfilePageProps {
  onNavigateToList: (listType: "reading" | "saved") => void;
}

interface UserProfile {
  username: string;
  name: string;
  email: string;
  bio: string;
  location: string;
  website: string;
  profileImage: string;
}

// Mock user data
const initialUserData: UserProfile = {
  username: "@johndoe",
  name: "John Doe",
  email: "john.doe@example.com",
  bio: "Passionate writer and avid reader. Love exploring tech, science, and lifestyle topics.",
  location: "San Francisco, CA",
  website: "johndoe.com",
  profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
};

// Mock reading list
const readingList = [
  {
    id: 1,
    title: "The Future of Artificial Intelligence in Healthcare",
    status: "reading",
    progress: 65,
  },
  {
    id: 2,
    title: "Building Scalable Web Applications",
    status: "completed",
    progress: 100,
  },
  {
    id: 3,
    title: "Understanding Quantum Physics for Beginners",
    status: "reading",
    progress: 30,
  },
];

// Mock saved list
const savedList = [
  {
    id: 4,
    title: "Space Exploration: Journey to Mars",
    savedDate: "Nov 12, 2025",
  },
  {
    id: 5,
    title: "Digital Marketing Strategies for 2025",
    savedDate: "Nov 10, 2025",
  },
  {
    id: 6,
    title: "The Complete Guide to Mindful Living",
    savedDate: "Nov 8, 2025",
  },
];

export function ProfilePage({ onNavigateToList }: ProfilePageProps) {
  const [isEditMode, setIsEditMode] = useState(false);
  const [userData, setUserData] = useState<UserProfile>(initialUserData);
  const [editedData, setEditedData] = useState<UserProfile>(initialUserData);

  const handleEditClick = () => {
    setIsEditMode(true);
    setEditedData(userData);
  };

  const handleCancelEdit = () => {
    setIsEditMode(false);
    setEditedData(userData);
  };

  const handleSaveChanges = () => {
    setUserData(editedData);
    setIsEditMode(false);
  };

  const handleInputChange = (field: keyof UserProfile, value: string) => {
    setEditedData({ ...editedData, [field]: value });
  };

  const displayData = isEditMode ? editedData : userData;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex gap-8">
        {/* Left Section - User Info */}
        <div className="flex-1">
          <div className="bg-white rounded-2xl shadow-sm p-8">
            {/* Edit Button */}
            {!isEditMode && (
              <button
                onClick={handleEditClick}
                className="flex items-center gap-2 px-4 py-2 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors mb-6"
              >
                <Edit2 className="w-4 h-4" />
                Edit Profile Info
              </button>
            )}

            {/* User Details */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm text-[#897684] mb-2">Username</label>
                {isEditMode ? (
                  <input
                    type="text"
                    value={displayData.username}
                    onChange={(e) => handleInputChange("username", e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
                  />
                ) : (
                  <p className="text-[#294713]">{displayData.username}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#897684] mb-2">Name</label>
                {isEditMode ? (
                  <input
                    type="text"
                    value={displayData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
                  />
                ) : (
                  <p className="text-[#294713]">{displayData.name}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#897684] mb-2">Email</label>
                {isEditMode ? (
                  <input
                    type="email"
                    value={displayData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
                  />
                ) : (
                  <p className="text-[#294713]">{displayData.email}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#897684] mb-2">Bio</label>
                {isEditMode ? (
                  <textarea
                    value={displayData.bio}
                    onChange={(e) => handleInputChange("bio", e.target.value)}
                    rows={3}
                    className="w-full px-4 py-2 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713] resize-none"
                  />
                ) : (
                  <p className="text-[#294713]">{displayData.bio}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#897684] mb-2">Location</label>
                {isEditMode ? (
                  <input
                    type="text"
                    value={displayData.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
                  />
                ) : (
                  <p className="text-[#294713]">{displayData.location}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#897684] mb-2">Website</label>
                {isEditMode ? (
                  <input
                    type="text"
                    value={displayData.website}
                    onChange={(e) => handleInputChange("website", e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
                  />
                ) : (
                  <p className="text-[#294713]">{displayData.website}</p>
                )}
              </div>
            </div>

            {/* Action Buttons in Edit Mode */}
            {isEditMode && (
              <div className="flex gap-3 mt-8">
                <button
                  onClick={handleSaveChanges}
                  className="flex-1 px-6 py-3 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors"
                >
                  Save Changes
                </button>
                <button
                  onClick={handleCancelEdit}
                  className="flex-1 px-6 py-3 bg-[#897684]/10 text-[#897684] rounded-xl hover:bg-[#897684]/20 transition-colors"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Section - Profile Image & Lists */}
        <div className="w-[400px] space-y-6">
          {/* Profile Image */}
          <div className="bg-white rounded-2xl shadow-sm p-6">
            <div className="flex flex-col items-center">
              <div className="relative">
                <img
                  src={displayData.profileImage}
                  alt="Profile"
                  className="w-40 h-40 rounded-full object-cover border-4 border-[#BBA767]/20"
                />
                {isEditMode && (
                  <button className="absolute bottom-0 right-0 p-3 bg-[#7CA74B] text-white rounded-full hover:bg-[#294713] transition-colors shadow-lg">
                    <Camera className="w-5 h-5" />
                  </button>
                )}
              </div>
              {isEditMode && (
                <button className="mt-4 text-[#7CA74B] hover:text-[#294713] transition-colors">
                  Change Profile Image
                </button>
              )}
            </div>
          </div>

          {/* Reading List */}
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <button
              onClick={() => onNavigateToList("reading")}
              className="w-full p-6 text-left hover:bg-[#BBA767]/5 transition-colors group"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-[#7CA74B]/10 rounded-lg">
                  <BookOpen className="w-5 h-5 text-[#7CA74B]" />
                </div>
                <h3 className="text-[#294713] group-hover:text-[#7CA74B] transition-colors">
                  Reading List
                </h3>
              </div>
              <ArticleListCompact articles={readingList} type="reading" />
            </button>
          </div>

          {/* Saved List */}
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <button
              onClick={() => onNavigateToList("saved")}
              className="w-full p-6 text-left hover:bg-[#BBA767]/5 transition-colors group"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-[#BBA767]/10 rounded-lg">
                  <Bookmark className="w-5 h-5 text-[#BBA767]" />
                </div>
                <h3 className="text-[#294713] group-hover:text-[#7CA74B] transition-colors">
                  Saved List
                </h3>
              </div>
              <ArticleListCompact articles={savedList} type="saved" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
