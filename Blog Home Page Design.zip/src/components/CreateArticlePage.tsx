import { useState } from "react";
import { Image as ImageIcon, Bold, Italic, List, Link as LinkIcon, X } from "lucide-react";

interface CreateArticlePageProps {
  onPublish: (article: any) => void;
  onSaveDraft: (article: any) => void;
}

const categories = [
  { id: "technology", name: "Technology", subcategories: ["AI", "Software", "Gadgets", "Programming", "Cybersecurity"] },
  { id: "science", name: "Science", subcategories: ["Biology", "Space", "Physics", "Environment", "Research"] },
  { id: "business", name: "Business", subcategories: ["Startups", "Marketing", "Finance", "Entrepreneurship", "Management"] },
  { id: "lifestyle", name: "Lifestyle", subcategories: ["Health", "Fitness", "Food", "Travel", "Minimalism", "Home"] },
  { id: "personal-growth", name: "Personal Growth", subcategories: ["Motivation", "Productivity", "Psychology", "Self-improvement", "Life lessons"] },
  { id: "writing-creativity", name: "Writing / Creativity", subcategories: ["Storytelling", "Poetry", "Novel writing", "Journaling", "Art and design"] },
  { id: "society-culture", name: "Society & Culture", subcategories: ["Social issues", "Education", "Culture & tradition", "Relationships", "Philosophy"] },
  { id: "entertainment", name: "Entertainment", subcategories: ["Movies", "Anime", "Music", "Books", "Gaming"] },
  { id: "politics", name: "Politics", subcategories: ["Current affairs", "Policy", "Global issues", "Debates"] },
  { id: "environment-nature", name: "Environment & Nature", subcategories: ["Sustainability", "Climate", "Wildlife", "Gardening"] },
  { id: "career-education", name: "Career & Education", subcategories: ["Career advice", "Skill development", "Study tips", "College life"] },
];

export function CreateArticlePage({ onPublish, onSaveDraft }: CreateArticlePageProps) {
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [mainImage, setMainImage] = useState("");
  const [body, setBody] = useState("");
  const [additionalImages, setAdditionalImages] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSubcategory, setSelectedSubcategory] = useState("");
  const [imageInput, setImageInput] = useState("");

  const handleAddImage = () => {
    if (imageInput.trim()) {
      setAdditionalImages([...additionalImages, imageInput]);
      setImageInput("");
    }
  };

  const handleRemoveImage = (index: number) => {
    setAdditionalImages(additionalImages.filter((_, i) => i !== index));
  };

  const handleFormatText = (format: string) => {
    // Simple text formatting - in real app, would use a rich text editor
    const textarea = document.querySelector('textarea[name="body"]') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = body.substring(start, end);
    
    let formattedText = "";
    switch (format) {
      case "bold":
        formattedText = `**${selectedText}**`;
        break;
      case "italic":
        formattedText = `*${selectedText}*`;
        break;
      case "list":
        formattedText = `\n- ${selectedText}`;
        break;
      default:
        formattedText = selectedText;
    }

    const newBody = body.substring(0, start) + formattedText + body.substring(end);
    setBody(newBody);
  };

  const handlePublish = () => {
    if (!title || !body || !selectedCategory) {
      alert("Please fill in the title, body, and select a category before publishing.");
      return;
    }

    const article = {
      id: Date.now(),
      title,
      subtitle,
      mainImage: mainImage || "https://images.unsplash.com/photo-1617634667039-8e4cb277ab46?w=1080",
      body,
      additionalImages,
      category: selectedCategory,
      subcategory: selectedSubcategory,
      categoryKey: selectedSubcategory ? `${selectedCategory}-${selectedSubcategory}` : selectedCategory,
      author: "John Doe",
      readTime: `${Math.ceil(body.split(" ").length / 200)} min read`,
      publishDate: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }),
      excerpt: body.substring(0, 150) + "...",
      likes: 0,
      comments: [],
      saved: false,
    };

    onPublish(article);
    alert("Article published successfully!");
    
    // Reset form
    setTitle("");
    setSubtitle("");
    setMainImage("");
    setBody("");
    setAdditionalImages([]);
    setSelectedCategory("");
    setSelectedSubcategory("");
  };

  const handleSaveDraft = () => {
    const draft = {
      id: Date.now(),
      title,
      subtitle,
      mainImage,
      body,
      additionalImages,
      category: selectedCategory,
      subcategory: selectedSubcategory,
      updatedAt: new Date().toISOString(),
    };

    onSaveDraft(draft);
    alert("Draft saved successfully!");
  };

  const selectedCategoryData = categories.find(cat => cat.name === selectedCategory);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-sm p-8">
        <h1 className="text-[#294713] mb-8">Create New Article</h1>

        <div className="space-y-6">
          {/* Title */}
          <div>
            <label className="block text-sm text-[#897684] mb-2">Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter your article title..."
              className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
            />
          </div>

          {/* Subtitle */}
          <div>
            <label className="block text-sm text-[#897684] mb-2">Subtitle</label>
            <input
              type="text"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              placeholder="Enter a subtitle (optional)..."
              className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
            />
          </div>

          {/* Main Image */}
          <div>
            <label className="block text-sm text-[#897684] mb-2">Main Image URL</label>
            <input
              type="text"
              value={mainImage}
              onChange={(e) => setMainImage(e.target.value)}
              placeholder="Enter image URL..."
              className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
            />
            {mainImage && (
              <div className="mt-3 rounded-xl overflow-hidden">
                <img src={mainImage} alt="Preview" className="w-full h-48 object-cover" />
              </div>
            )}
          </div>

          {/* Category Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-[#897684] mb-2">Main Category *</label>
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setSelectedSubcategory("");
                }}
                className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
              >
                <option value="">Select category...</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.name}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm text-[#897684] mb-2">Sub Category (Optional)</label>
              <select
                value={selectedSubcategory}
                onChange={(e) => setSelectedSubcategory(e.target.value)}
                disabled={!selectedCategory}
                className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713] disabled:bg-[#897684]/5"
              >
                <option value="">Select subcategory...</option>
                {selectedCategoryData?.subcategories.map((sub) => (
                  <option key={sub} value={sub}>
                    {sub}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Formatting Toolbar */}
          <div>
            <label className="block text-sm text-[#897684] mb-2">Article Body *</label>
            <div className="flex gap-2 mb-2 p-2 bg-[#F5F1E8] rounded-xl">
              <button
                onClick={() => handleFormatText("bold")}
                className="p-2 hover:bg-white rounded-lg transition-colors"
                title="Bold"
              >
                <Bold className="w-4 h-4 text-[#294713]" />
              </button>
              <button
                onClick={() => handleFormatText("italic")}
                className="p-2 hover:bg-white rounded-lg transition-colors"
                title="Italic"
              >
                <Italic className="w-4 h-4 text-[#294713]" />
              </button>
              <button
                onClick={() => handleFormatText("list")}
                className="p-2 hover:bg-white rounded-lg transition-colors"
                title="List"
              >
                <List className="w-4 h-4 text-[#294713]" />
              </button>
            </div>
            <textarea
              name="body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Write your article content here..."
              rows={15}
              className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713] resize-none"
            />
          </div>

          {/* Additional Images */}
          <div>
            <label className="block text-sm text-[#897684] mb-2">Additional Images</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={imageInput}
                onChange={(e) => setImageInput(e.target.value)}
                placeholder="Enter image URL and click Add..."
                className="flex-1 px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713]"
              />
              <button
                onClick={handleAddImage}
                className="px-6 py-3 bg-[#BBA767] text-white rounded-xl hover:bg-[#897684] transition-colors flex items-center gap-2"
              >
                <ImageIcon className="w-4 h-4" />
                Add
              </button>
            </div>

            {additionalImages.length > 0 && (
              <div className="mt-4 grid grid-cols-3 gap-4">
                {additionalImages.map((img, index) => (
                  <div key={index} className="relative rounded-xl overflow-hidden group">
                    <img src={img} alt={`Additional ${index + 1}`} className="w-full h-32 object-cover" />
                    <button
                      onClick={() => handleRemoveImage(index)}
                      className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <button
              onClick={handlePublish}
              className="flex-1 px-6 py-3 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors"
            >
              Publish Article
            </button>
            <button
              onClick={handleSaveDraft}
              className="flex-1 px-6 py-3 bg-[#BBA767]/20 text-[#294713] rounded-xl hover:bg-[#BBA767]/30 transition-colors"
            >
              Save as Draft
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
