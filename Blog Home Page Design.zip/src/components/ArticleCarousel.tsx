import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Article {
  id: number;
  title: string;
  image: string;
}

interface ArticleCarouselProps {
  category: string;
  articles: Article[];
  autoPlayInterval?: number;
  onArticleClick?: (articleId: number) => void;
}

export function ArticleCarousel({
  category,
  articles,
  autoPlayInterval = 15000,
  onArticleClick,
}: ArticleCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % articles.length);
    }, autoPlayInterval);

    return () => clearInterval(timer);
  }, [currentIndex, isPaused, articles.length, autoPlayInterval]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? articles.length - 1 : prevIndex - 1
    );
  };

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % articles.length);
  };

  return (
    <div
      className="relative w-full h-[160px] rounded-3xl overflow-hidden shadow-md bg-white group"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="absolute inset-0 cursor-pointer"
          onClick={() => onArticleClick && onArticleClick(articles[currentIndex].id)}
        >
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url(${articles[currentIndex].image})`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#294713]/90 via-[#294713]/50 to-transparent" />
          
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="text-[#BBA767] mb-1 tracking-widest text-xs uppercase">
              {category}
            </div>
            <h3 className="text-white max-w-2xl">
              {articles[currentIndex].title}
            </h3>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Buttons */}
      <button
        onClick={goToPrevious}
        className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/90 backdrop-blur-sm text-[#294713] opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white shadow-lg"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button
        onClick={goToNext}
        className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/90 backdrop-blur-sm text-[#294713] opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white shadow-lg"
        aria-label="Next slide"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-3 right-4 flex gap-1.5">
        {articles.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-1.5 rounded-full transition-all ${
              index === currentIndex
                ? "bg-[#BBA767] w-6"
                : "bg-white/50 hover:bg-white/70 w-1.5"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}