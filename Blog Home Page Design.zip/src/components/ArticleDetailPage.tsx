import { ArrowLeft, Clock, User, Calendar, Heart, MessageCircle, Bookmark, Share2 } from "lucide-react";
import { useState } from "react";

interface Comment {
  id: number;
  author: string;
  authorImage: string;
  text: string;
  date: string;
}

interface ArticleDetailPageProps {
  articleId: number;
  onBack: () => void;
}

export function ArticleDetailPage({ articleId, onBack }: ArticleDetailPageProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [likes, setLikes] = useState(124);
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      author: "Emily Chen",
      authorImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
      text: "This is a fantastic article! Really insightful perspective on AI in healthcare.",
      date: "2 days ago",
    },
    {
      id: 2,
      author: "Michael Roberts",
      authorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
      text: "Great read. Would love to see more content like this!",
      date: "1 day ago",
    },
  ]);
  const [newComment, setNewComment] = useState("");

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikes(isLiked ? likes - 1 : likes + 1);
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    // In real app, would save to user's saved list
  };

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: comments.length + 1,
        author: "John Doe",
        authorImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
        text: newComment,
        date: "Just now",
      };
      setComments([...comments, comment]);
      setNewComment("");
    }
  };

  // Mock article data - in a real app, this would fetch from an API
  const article = {
    id: articleId,
    title: "The Future of Artificial Intelligence in Healthcare",
    image: "https://images.unsplash.com/photo-1623715537851-8bc15aa8c145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlfGVufDF8fHx8MTc2MzA0OTc5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Sarah Johnson",
    authorBio: "Healthcare Technology Researcher",
    readTime: "8 min read",
    publishDate: "November 10, 2025",
    category: "Technology",
    content: `
      <p>Artificial Intelligence is transforming the healthcare industry in unprecedented ways. From diagnostic tools to personalized treatment plans, AI is revolutionizing how we approach medical care.</p>

      <h2>The Current State of AI in Healthcare</h2>
      <p>Today's healthcare systems are increasingly incorporating AI technologies to improve patient outcomes and streamline operations. Machine learning algorithms can now detect patterns in medical imaging that human eyes might miss, leading to earlier and more accurate diagnoses.</p>

      <h2>Key Applications</h2>
      <p>AI is being used in various healthcare domains including:</p>
      <ul>
        <li>Medical imaging and diagnostics</li>
        <li>Drug discovery and development</li>
        <li>Personalized treatment recommendations</li>
        <li>Patient monitoring and predictive analytics</li>
        <li>Administrative workflow optimization</li>
      </ul>

      <h2>Future Implications</h2>
      <p>As AI technology continues to advance, we can expect even more transformative changes in healthcare. The integration of AI with other emerging technologies like genomics and telemedicine will create new possibilities for preventive care and early intervention.</p>

      <p>However, it's crucial to address ethical considerations, data privacy concerns, and ensure that AI systems are transparent and unbiased. The future of healthcare will be shaped by how well we navigate these challenges while harnessing the power of AI.</p>

      <h2>Conclusion</h2>
      <p>The integration of AI in healthcare represents one of the most promising developments in modern medicine. As technology evolves and adoption increases, we're moving toward a future where healthcare is more accessible, accurate, and personalized than ever before.</p>
    `,
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#7CA74B] hover:text-[#294713] transition-colors mb-8"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Articles</span>
      </button>

      <article className="bg-white rounded-2xl shadow-sm overflow-hidden">
        {/* Header Image */}
        <div className="relative h-96 overflow-hidden">
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-8 left-8 right-8">
            <span className="inline-block px-4 py-1.5 bg-[#7CA74B] text-white rounded-full text-sm mb-4">
              {article.category}
            </span>
            <h1 className="text-white mb-4">{article.title}</h1>
          </div>
        </div>

        {/* Article Meta */}
        <div className="px-8 py-6 border-b border-[#BBA767]/20">
          <div className="flex items-center gap-6 text-sm text-[#897684]">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <div>
                <div className="text-[#294713]">{article.author}</div>
                <div className="text-xs">{article.authorBio}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{article.publishDate}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>{article.readTime}</span>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div
          className="px-8 py-8 prose prose-lg max-w-none"
          dangerouslySetInnerHTML={{ __html: article.content }}
          style={{
            color: "#294713",
          }}
        />
      </article>

      {/* Interaction Bar */}
      <div className="bg-white rounded-2xl shadow-sm p-6 mt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button
              onClick={handleLike}
              className={`flex items-center gap-2 transition-colors ${
                isLiked ? "text-red-500" : "text-[#897684] hover:text-red-500"
              }`}
            >
              <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
              <span>{likes}</span>
            </button>
            <button className="flex items-center gap-2 text-[#897684] hover:text-[#7CA74B] transition-colors">
              <MessageCircle className="w-5 h-5" />
              <span>{comments.length}</span>
            </button>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleSave}
              className={`p-2 rounded-xl transition-colors ${
                isSaved
                  ? "bg-[#BBA767] text-white"
                  : "bg-[#BBA767]/10 text-[#BBA767] hover:bg-[#BBA767]/20"
              }`}
            >
              <Bookmark className={`w-5 h-5 ${isSaved ? "fill-current" : ""}`} />
            </button>
            <button className="p-2 bg-[#7CA74B]/10 text-[#7CA74B] rounded-xl hover:bg-[#7CA74B]/20 transition-colors">
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Comments Section */}
      <div className="bg-white rounded-2xl shadow-sm p-8 mt-6">
        <h2 className="text-[#294713] mb-6">Comments ({comments.length})</h2>

        {/* Add Comment */}
        <div className="mb-8">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment..."
            rows={3}
            className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/20 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] text-[#294713] resize-none mb-3"
          />
          <button
            onClick={handleAddComment}
            className="px-6 py-2 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors"
          >
            Post Comment
          </button>
        </div>

        {/* Comments List */}
        <div className="space-y-6">
          {comments.map((comment) => (
            <div key={comment.id} className="flex gap-4">
              <img
                src={comment.authorImage}
                alt={comment.author}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[#294713]">{comment.author}</span>
                  <span className="text-xs text-[#897684]">{comment.date}</span>
                </div>
                <p className="text-[#897684]">{comment.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Author Profile */}
      <div className="bg-white rounded-2xl shadow-sm p-8 mt-6">
        <h3 className="text-[#294713] mb-6">About the Author</h3>
        <div className="flex gap-6">
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&h=120&fit=crop"
            alt={article.author}
            className="w-20 h-20 rounded-full object-cover"
          />
          <div className="flex-1">
            <h4 className="text-[#294713] mb-2">{article.author}</h4>
            <p className="text-[#897684] mb-4">{article.authorBio}</p>
            <button className="px-4 py-2 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors">
              Follow
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
