import { useState } from "react";
import { X, Mail, Lock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import bgImage from "figma:asset/8f1af347a0a5b4c10a7815e17bb2f072f88d183a.png";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export function LoginModal({ isOpen, onClose, onLoginSuccess }: LoginModalProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [username, setUsername] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSignUp) {
      if (password !== confirmPassword) {
        alert("Passwords don't match!");
        return;
      }
      // Simulate sign up
      alert("Account created successfully!");
      setIsSignUp(false);
      resetForm();
    } else {
      // Simulate login
      if (email && password) {
        onLoginSuccess();
        resetForm();
      } else {
        alert("Please fill in all fields");
      }
    }
  };

  const resetForm = () => {
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    setUsername("");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50"
            style={{
              backgroundImage: `url(${bgImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <div className="absolute inset-0 bg-[#294713]/90 backdrop-blur-sm" />
          </motion.div>

          {/* Modal */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md"
            >
              <div className="bg-white/95 backdrop-blur-md rounded-3xl shadow-2xl p-8 border border-[#BBA767]/20">
                {/* Close Button */}
                <button
                  onClick={onClose}
                  className="absolute top-4 right-4 p-2 hover:bg-[#897684]/10 rounded-xl transition-colors"
                >
                  <X className="w-5 h-5 text-[#294713]" />
                </button>

                {/* Header */}
                <div className="text-center mb-8">
                  <h2 className="text-[#294713] text-3xl mb-2">
                    {isSignUp ? "Create Account" : "Welcome Back"}
                  </h2>
                  <p className="text-[#897684]">
                    {isSignUp
                      ? "Join our community of readers and writers"
                      : "Login to continue your journey"}
                  </p>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="space-y-5">
                  {isSignUp && (
                    <div>
                      <label className="block text-sm text-[#897684] mb-2">
                        Username
                      </label>
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Choose a username"
                        className="w-full px-4 py-3 rounded-xl border border-[#BBA767]/30 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] focus:border-transparent text-[#294713] bg-white"
                        required={isSignUp}
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-sm text-[#897684] mb-2">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#897684]/60" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"
                        className="w-full pl-11 pr-4 py-3 rounded-xl border border-[#BBA767]/30 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] focus:border-transparent text-[#294713] bg-white"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-[#897684] mb-2">
                      Password
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#897684]/60" />
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter your password"
                        className="w-full pl-11 pr-4 py-3 rounded-xl border border-[#BBA767]/30 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] focus:border-transparent text-[#294713] bg-white"
                        required
                      />
                    </div>
                  </div>

                  {isSignUp && (
                    <div>
                      <label className="block text-sm text-[#897684] mb-2">
                        Confirm Password
                      </label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#897684]/60" />
                        <input
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Confirm your password"
                          className="w-full pl-11 pr-4 py-3 rounded-xl border border-[#BBA767]/30 focus:outline-none focus:ring-2 focus:ring-[#7CA74B] focus:border-transparent text-[#294713] bg-white"
                          required={isSignUp}
                        />
                      </div>
                    </div>
                  )}

                  {!isSignUp && (
                    <div className="flex items-center justify-end">
                      <button
                        type="button"
                        className="text-sm text-[#7CA74B] hover:text-[#294713] transition-colors"
                      >
                        Forgot Password?
                      </button>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#7CA74B] text-white rounded-xl hover:bg-[#294713] transition-colors shadow-lg"
                  >
                    {isSignUp ? "Create Account" : "Login"}
                  </button>
                </form>

                {/* Toggle Sign Up / Login */}
                <div className="mt-6 text-center">
                  <p className="text-[#897684]">
                    {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                    <button
                      onClick={() => {
                        setIsSignUp(!isSignUp);
                        resetForm();
                      }}
                      className="text-[#7CA74B] hover:text-[#294713] transition-colors"
                    >
                      {isSignUp ? "Login" : "Create Account"}
                    </button>
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
