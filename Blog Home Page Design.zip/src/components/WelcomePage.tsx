import { useState } from "react";
import { BookOpen, Users, TrendingUp, Award, ArrowRight } from "lucide-react";
import { LoginModal } from "./LoginModal";
import bgImage from "figma:asset/8f1af347a0a5b4c10a7815e17bb2f072f88d183a.png";

interface WelcomePageProps {
  onLogin: () => void;
}

export function WelcomePage({ onLogin }: WelcomePageProps) {
  const [showLoginModal, setShowLoginModal] = useState(false);

  const handleLoginSuccess = () => {
    setShowLoginModal(false);
    onLogin();
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${bgImage})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#294713]/80 via-[#294713]/60 to-[#294713]/80" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="px-6 py-6">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 backdrop-blur-sm rounded-xl">
                <BookOpen className="w-8 h-8 text-[#BBA767]" />
              </div>
              <div>
                <h1 className="text-white text-2xl">NatureReads</h1>
                <p className="text-[#BBA767] text-sm">Stories from Nature</p>
              </div>
            </div>
            <button
              onClick={() => setShowLoginModal(true)}
              className="px-6 py-3 bg-[#7CA74B] text-white rounded-xl hover:bg-[#57C952] transition-colors"
            >
              Login
            </button>
          </div>
        </header>

        {/* Hero Section */}
        <section className="px-6 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-white text-5xl mb-6">
              Discover Stories That Inspire
            </h2>
            <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
              Join our community of writers and readers exploring topics from technology to nature, 
              lifestyle to creativity. Share your voice with the world.
            </p>
            <button
              onClick={() => setShowLoginModal(true)}
              className="px-8 py-4 bg-[#BBA767] text-white rounded-xl hover:bg-[#897684] transition-colors inline-flex items-center gap-3 text-lg shadow-xl"
            >
              Get Started
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </section>

        {/* Features Section */}
        <section className="px-6 py-16">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <div className="p-3 bg-[#7CA74B]/20 rounded-xl w-fit mb-4">
                  <BookOpen className="w-8 h-8 text-[#BBA767]" />
                </div>
                <h3 className="text-white text-xl mb-3">Read & Write</h3>
                <p className="text-white/80">
                  Access thousands of articles across diverse topics. Share your own stories and insights with our community.
                </p>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <div className="p-3 bg-[#57C952]/20 rounded-xl w-fit mb-4">
                  <Users className="w-8 h-8 text-[#BBA767]" />
                </div>
                <h3 className="text-white text-xl mb-3">Join Community</h3>
                <p className="text-white/80">
                  Connect with like-minded readers and writers. Engage through comments, likes, and meaningful discussions.
                </p>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                <div className="p-3 bg-[#BBA767]/20 rounded-xl w-fit mb-4">
                  <TrendingUp className="w-8 h-8 text-[#BBA767]" />
                </div>
                <h3 className="text-white text-xl mb-3">Grow Your Audience</h3>
                <p className="text-white/80">
                  Build your following, track your article performance, and establish yourself as a thought leader.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="px-6 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-12 border border-white/20">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                  <div className="text-[#BBA767] text-4xl mb-2">10K+</div>
                  <div className="text-white/80">Active Readers</div>
                </div>
                <div>
                  <div className="text-[#BBA767] text-4xl mb-2">5K+</div>
                  <div className="text-white/80">Published Articles</div>
                </div>
                <div>
                  <div className="text-[#BBA767] text-4xl mb-2">50+</div>
                  <div className="text-white/80">Categories</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="px-6 py-20">
          <div className="max-w-3xl mx-auto text-center">
            <div className="p-4 bg-[#7CA74B]/20 rounded-full w-fit mx-auto mb-6">
              <Award className="w-12 h-12 text-[#BBA767]" />
            </div>
            <h3 className="text-white text-3xl mb-4">
              Ready to Start Your Journey?
            </h3>
            <p className="text-white/90 text-lg mb-8">
              Join thousands of readers and writers today. It's free to get started.
            </p>
            <button
              onClick={() => setShowLoginModal(true)}
              className="px-8 py-4 bg-[#7CA74B] text-white rounded-xl hover:bg-[#57C952] transition-colors inline-flex items-center gap-3 text-lg shadow-xl"
            >
              Login to Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-6 py-8 border-t border-white/10">
          <div className="max-w-7xl mx-auto text-center text-white/60">
            <p>&copy; 2025 NatureReads. All rights reserved.</p>
          </div>
        </footer>
      </div>

      {/* Login Modal */}
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
}
