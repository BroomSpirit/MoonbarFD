import { useState } from "react";
import { ArrowLeft, Eye, Heart, MessageCircle, CheckCircle } from "lucide-react";

interface PublishedArticle {
  id: number;
  title: string;
  category: string;
  subcategory: string;
  publishedAt: string;
  views: number;
  likes: number;
  comments: number;
  image: string;
}

const mockPublished: PublishedArticle[] = [
  {
    id: 1,
    title: "The Future of Artificial Intelligence in Healthcare",
    category: "Technology",
    subcategory: "AI",
    publishedAt: "2025-11-10T14:30:00",
    views: 1240,
    likes: 89,
    comments: 23,
    image: "https://images.unsplash.com/photo-1623715537851-8bc15aa8c145?w=400&h=250&fit=crop",
  },
  {
    id: 2,
    title: "Building Scalable Web Applications",
    category: "Technology",
    subcategory: "Software",
    publishedAt: "2025-11-08T09:15:00",
    views: 856,
    likes: 67,
    comments: 15,
    image: "https://images.unsplash.com/photo-1519217651866-847339e674d4?w=400&h=250&fit=crop",
  },
];

interface PublishedPageProps {
  onBack: () => void;
  onArticleClick: (articleId: number) => void;
}

export function PublishedPage({ onBack, onArticleClick }: PublishedPageProps) {
  const [articles] = useState<PublishedArticle[]>(mockPublished);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#7CA74B] hover:text-[#294713] transition-colors mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back</span>
      </button>

      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-[#57C952]/10 rounded-xl">
          <CheckCircle className="w-6 h-6 text-[#57C952]" />
        </div>
        <div>
          <h1 className="text-[#294713]">Published Articles</h1>
          <p className="text-[#897684]">{articles.length} article{articles.length !== 1 ? "s" : ""} published</p>
        </div>
      </div>

      <div className="space-y-4">
        {articles.map((article) => (
          <div
            key={article.id}
            onClick={() => onArticleClick(article.id)}
            className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer group"
          >
            <div className="flex">
              <div className="w-64 h-40 flex-shrink-0">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="flex-1 p-6">
                <h3 className="text-[#294713] mb-2 group-hover:text-[#7CA74B] transition-colors">
                  {article.title}
                </h3>
                <div className="flex items-center gap-3 mb-4 text-sm">
                  <span className="px-3 py-1 bg-[#7CA74B]/10 text-[#7CA74B] rounded-full">
                    {article.category}
                  </span>
                  {article.subcategory && (
                    <span className="px-3 py-1 bg-[#BBA767]/10 text-[#BBA767] rounded-full">
                      {article.subcategory}
                    </span>
                  )}
                  <span className="text-[#897684]">Published {formatDate(article.publishedAt)}</span>
                </div>
                <div className="flex items-center gap-6 text-sm text-[#897684]">
                  <div className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    <span>{article.views.toLocaleString()} views</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    <span>{article.likes} likes</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4" />
                    <span>{article.comments} comments</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {articles.length === 0 && (
          <div className="text-center py-20">
            <CheckCircle className="w-16 h-16 text-[#897684]/30 mx-auto mb-4" />
            <p className="text-[#897684]">No published articles yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
