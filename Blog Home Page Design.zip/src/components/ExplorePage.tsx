import { useState } from "react";
import { FilterSidebar, FilterCategory } from "./FilterSidebar";
import { ArticleCard } from "./ArticleCard";

interface Article {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  readTime: string;
  category: string;
  categoryKey: string;
}

const filterCategories: FilterCategory[] = [
  {
    id: "technology",
    name: "Technology",
    subcategories: ["AI", "Software", "Gadgets", "Programming", "Cybersecurity"],
  },
  {
    id: "science",
    name: "Science",
    subcategories: ["Biology", "Space", "Physics", "Environment", "Research"],
  },
  {
    id: "business",
    name: "Business",
    subcategories: ["Startups", "Marketing", "Finance", "Entrepreneurship", "Management"],
  },
  {
    id: "lifestyle",
    name: "Lifestyle",
    subcategories: ["Health", "Fitness", "Food", "Travel", "Minimalism", "Home"],
  },
  {
    id: "personal-growth",
    name: "Personal Growth",
    subcategories: ["Motivation", "Productivity", "Psychology", "Self-improvement", "Life lessons"],
  },
  {
    id: "writing-creativity",
    name: "Writing / Creativity",
    subcategories: ["Storytelling", "Poetry", "Novel writing", "Journaling", "Art and design"],
  },
  {
    id: "society-culture",
    name: "Society & Culture",
    subcategories: ["Social issues", "Education", "Culture & tradition", "Relationships", "Philosophy"],
  },
  {
    id: "entertainment",
    name: "Entertainment",
    subcategories: ["Movies", "Anime", "Music", "Books", "Gaming"],
  },
  {
    id: "politics",
    name: "Politics",
    subcategories: ["Current affairs", "Policy", "Global issues", "Debates"],
  },
  {
    id: "environment-nature",
    name: "Environment & Nature",
    subcategories: ["Sustainability", "Climate", "Wildlife", "Gardening"],
  },
  {
    id: "career-education",
    name: "Career & Education",
    subcategories: ["Career advice", "Skill development", "Study tips", "College life"],
  },
];

// Mock articles data
const allArticles: Article[] = [
  {
    id: 1,
    title: "The Future of Artificial Intelligence in Healthcare",
    excerpt: "Exploring how AI is revolutionizing medical diagnosis and patient care in modern healthcare systems.",
    image: "https://images.unsplash.com/photo-1623715537851-8bc15aa8c145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlfGVufDF8fHx8MTc2MzA0OTc5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Sarah Johnson",
    readTime: "8 min read",
    category: "AI",
    categoryKey: "Technology-AI",
  },
  {
    id: 2,
    title: "Building Scalable Web Applications with Modern Frameworks",
    excerpt: "A comprehensive guide to creating robust and scalable web applications using the latest technologies.",
    image: "https://images.unsplash.com/photo-1519217651866-847339e674d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NjMwMTYzNDl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Michael Chen",
    readTime: "12 min read",
    category: "Software",
    categoryKey: "Technology-Software",
  },
  {
    id: 3,
    title: "Understanding Quantum Physics for Beginners",
    excerpt: "A beginner-friendly introduction to the fascinating world of quantum mechanics and its implications.",
    image: "https://images.unsplash.com/photo-1617634667039-8e4cb277ab46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmUlMjBsYW5kc2NhcGV8ZW58MXx8fHwxNzYzMTM1MDM3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Dr. Emma Watson",
    readTime: "15 min read",
    category: "Physics",
    categoryKey: "Science-Physics",
  },
  {
    id: 4,
    title: "Space Exploration: Journey to Mars",
    excerpt: "The latest developments in space technology and humanity's quest to reach the Red Planet.",
    image: "https://images.unsplash.com/photo-1490735891913-40897cdaafd1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjBza3l8ZW58MXx8fHwxNzYzMDgwMDcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "James Rodriguez",
    readTime: "10 min read",
    category: "Space",
    categoryKey: "Science-Space",
  },
  {
    id: 5,
    title: "Startup Success Stories: From Garage to IPO",
    excerpt: "Inspiring stories of entrepreneurs who built billion-dollar companies from humble beginnings.",
    image: "https://images.unsplash.com/photo-1762530351329-5206c031bb1e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1cmJhbiUyMGNpdHlzY2FwZXxlbnwxfHx8fDE3NjMwNDM1MjF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Lisa Anderson",
    readTime: "7 min read",
    category: "Startups",
    categoryKey: "Business-Startups",
  },
  {
    id: 6,
    title: "Digital Marketing Strategies for 2025",
    excerpt: "Stay ahead of the curve with these cutting-edge digital marketing tactics and trends.",
    image: "https://images.unsplash.com/photo-1528262004378-a108d795029c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwZGVzaWdufGVufDF8fHx8MTc2MzEwMjQ1N3ww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "David Park",
    readTime: "9 min read",
    category: "Marketing",
    categoryKey: "Business-Marketing",
  },
  {
    id: 7,
    title: "The Complete Guide to Mindful Living",
    excerpt: "Transform your daily routine with mindfulness practices that promote well-being and happiness.",
    image: "https://images.unsplash.com/photo-1610060616036-09bd2c69e8d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWZlc3R5bGUlMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjMxNDI3ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Maria Garcia",
    readTime: "6 min read",
    category: "Health",
    categoryKey: "Lifestyle-Health",
  },
  {
    id: 8,
    title: "Plant-Based Nutrition: A Beginner's Guide",
    excerpt: "Everything you need to know about transitioning to a healthy plant-based diet.",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcGhvdG9ncmFwaHl8ZW58MXx8fHwxNzYzMTI5NzU3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Alex Turner",
    readTime: "11 min read",
    category: "Food",
    categoryKey: "Lifestyle-Food",
  },
  {
    id: 9,
    title: "Productivity Hacks for Remote Workers",
    excerpt: "Boost your efficiency and maintain work-life balance while working from home.",
    image: "https://images.unsplash.com/photo-1518057111178-44a106bad636?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBtb3JuaW5nfGVufDF8fHx8MTc2MzA3NzE1MHww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Chris Williams",
    readTime: "5 min read",
    category: "Productivity",
    categoryKey: "Personal Growth-Productivity",
  },
  {
    id: 10,
    title: "The Art of Storytelling in Modern Literature",
    excerpt: "Discover techniques that master writers use to captivate readers and create memorable stories.",
    image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb3Jlc3QlMjB0cmVlc3xlbnwxfHx8fDE3NjMwNjA0NDV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Rachel Green",
    readTime: "13 min read",
    category: "Storytelling",
    categoryKey: "Writing / Creativity-Storytelling",
  },
  {
    id: 11,
    title: "Understanding Climate Change: Facts and Solutions",
    excerpt: "A deep dive into climate science and actionable steps we can take to protect our planet.",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMGJlYWNofGVufDF8fHx8MTc2MzEyNDg3OXww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Dr. Robert Lee",
    readTime: "14 min read",
    category: "Climate",
    categoryKey: "Environment & Nature-Climate",
  },
  {
    id: 12,
    title: "Career Transitions: Making the Leap Successfully",
    excerpt: "Expert advice on navigating career changes and finding fulfillment in your professional life.",
    image: "https://images.unsplash.com/photo-1578592391689-0e3d1a1b52b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZ3xlbnwxfHx8fDE3NjMxMzExNTB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Jennifer Smith",
    readTime: "10 min read",
    category: "Career advice",
    categoryKey: "Career & Education-Career advice",
  },
  {
    id: 13,
    title: "Cybersecurity Best Practices for 2025",
    excerpt: "Protect yourself and your organization from evolving cyber threats with these essential strategies.",
    image: "https://images.unsplash.com/photo-1623715537851-8bc15aa8c145?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwd29ya3NwYWNlfGVufDF8fHx8MTc2MzA0OTc5MHww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Kevin Zhang",
    readTime: "9 min read",
    category: "Cybersecurity",
    categoryKey: "Technology-Cybersecurity",
  },
  {
    id: 14,
    title: "The Psychology of Motivation and Achievement",
    excerpt: "Unlock your potential by understanding the science behind motivation and goal-setting.",
    image: "https://images.unsplash.com/photo-1559150182-a7144f7628f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYXJkZW4lMjBmbG93ZXJzfGVufDF8fHx8MTc2MzEwOTk4Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Dr. Amanda White",
    readTime: "11 min read",
    category: "Psychology",
    categoryKey: "Personal Growth-Psychology",
  },
  {
    id: 15,
    title: "Anime Masterpieces: A Curated Guide",
    excerpt: "Explore the finest works of Japanese animation that have shaped the medium and inspired millions.",
    image: "https://images.unsplash.com/photo-1528543606781-2f6e6857f318?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBhZHZlbnR1cmV8ZW58MXx8fHwxNzYzMTIzNjEzfDA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Yuki Tanaka",
    readTime: "8 min read",
    category: "Anime",
    categoryKey: "Entertainment-Anime",
  },
];

interface ExplorePageProps {
  onArticleClick: (articleId: number) => void;
  searchQuery?: string;
  userPublishedArticles?: any[];
}

export function ExplorePage({ onArticleClick, searchQuery = "", userPublishedArticles = [] }: ExplorePageProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);

  const handleCategorySelect = (category: string | null, subcategory: string | null) => {
    setSelectedCategory(category);
    setSelectedSubcategory(subcategory);
  };

  // Combine user published articles with existing articles
  const combinedArticles = [...userPublishedArticles, ...allArticles];

  // Filter logic:
  // - If both are null, show all articles (ALL selected)
  // - If category is selected but subcategory is null, show all articles from that category
  // - If both category and subcategory are selected, show only articles from that subcategory
  // - Apply search filter if search query exists
  let filteredArticles = !selectedCategory
    ? combinedArticles
    : !selectedSubcategory
    ? combinedArticles.filter((article) => article.categoryKey.startsWith(selectedCategory + "-"))
    : combinedArticles.filter((article) => article.categoryKey === `${selectedCategory}-${selectedSubcategory}`);

  // Apply search filter
  if (searchQuery.trim()) {
    filteredArticles = filteredArticles.filter((article) =>
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }

  return (
    <div className="flex gap-6 max-w-7xl mx-auto px-4 py-8">
      {/* Filters - 25% */}
      <div className="w-1/4">
        <FilterSidebar
          categories={filterCategories}
          selectedCategory={selectedCategory}
          selectedSubcategory={selectedSubcategory}
          onCategorySelect={handleCategorySelect}
        />
      </div>

      {/* Articles Grid - 75% */}
      <div className="w-3/4">
        <div className="mb-6">
          <h1 className="text-[#294713]">
            {searchQuery.trim()
              ? `Search results for "${searchQuery}"`
              : !selectedCategory
              ? "All Articles"
              : selectedSubcategory
              ? `${selectedCategory} - ${selectedSubcategory}`
              : selectedCategory}
          </h1>
          <p className="text-[#897684] mt-1">
            {filteredArticles.length} article{filteredArticles.length !== 1 ? "s" : ""} found
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <ArticleCard
              key={article.id}
              {...article}
              onClick={() => onArticleClick(article.id)}
            />
          ))}
        </div>

        {filteredArticles.length === 0 && (
          <div className="text-center py-20">
            <p className="text-[#897684]">No articles found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}