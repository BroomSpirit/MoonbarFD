import { useState } from "react";
import { ArrowLeft, BookmarkX, Bookmark } from "lucide-react";

interface SavedArticle {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  readTime: string;
  category: string;
  savedDate: string;
}

// Mock data
const savedArticles: SavedArticle[] = [
  {
    id: 4,
    title: "Space Exploration: Journey to Mars",
    excerpt: "The latest developments in space technology and humanity's quest to reach the Red Planet.",
    image: "https://images.unsplash.com/photo-1490735891913-40897cdaafd1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdW5zZXQlMjBza3l8ZW58MXx8fHwxNzYzMDgwMDcyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "James Rodriguez",
    readTime: "10 min read",
    category: "Science",
    savedDate: "Nov 12, 2025",
  },
  {
    id: 5,
    title: "Digital Marketing Strategies for 2025",
    excerpt: "Stay ahead of the curve with these cutting-edge digital marketing tactics and trends.",
    image: "https://images.unsplash.com/photo-1528262004378-a108d795029c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwZGVzaWdufGVufDF8fHx8MTc2MzEwMjQ1N3ww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "David Park",
    readTime: "9 min read",
    category: "Business",
    savedDate: "Nov 10, 2025",
  },
  {
    id: 6,
    title: "The Complete Guide to Mindful Living",
    excerpt: "Transform your daily routine with mindfulness practices that promote well-being and happiness.",
    image: "https://images.unsplash.com/photo-1610060616036-09bd2c69e8d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWZlc3R5bGUlMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjMxNDI3ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Maria Garcia",
    readTime: "6 min read",
    category: "Lifestyle",
    savedDate: "Nov 8, 2025",
  },
  {
    id: 7,
    title: "Productivity Hacks for Remote Workers",
    excerpt: "Boost your efficiency and maintain work-life balance while working from home.",
    image: "https://images.unsplash.com/photo-1518057111178-44a106bad636?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBtb3JuaW5nfGVufDF8fHx8MTc2MzA3NzE1MHww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Chris Williams",
    readTime: "5 min read",
    category: "Productivity",
    savedDate: "Nov 5, 2025",
  },
  {
    id: 8,
    title: "Understanding Climate Change: Facts and Solutions",
    excerpt: "A deep dive into climate science and actionable steps we can take to protect our planet.",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMGJlYWNofGVufDF8fHx8MTc2MzEyNDg3OXww&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Dr. Robert Lee",
    readTime: "14 min read",
    category: "Environment",
    savedDate: "Nov 3, 2025",
  },
  {
    id: 9,
    title: "The Art of Storytelling in Modern Literature",
    excerpt: "Discover techniques that master writers use to captivate readers and create memorable stories.",
    image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb3Jlc3QlMjB0cmVlc3xlbnwxfHx8fDE3NjMwNjA0NDV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    author: "Rachel Green",
    readTime: "13 min read",
    category: "Writing",
    savedDate: "Nov 1, 2025",
  },
];

interface SavedListPageProps {
  onBack: () => void;
  onArticleClick: (articleId: number) => void;
}

export function SavedListPage({ onBack, onArticleClick }: SavedListPageProps) {
  const [articles, setArticles] = useState<SavedArticle[]>(savedArticles);

  const handleUnsave = (articleId: number) => {
    setArticles(articles.filter((article) => article.id !== articleId));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#7CA74B] hover:text-[#294713] transition-colors mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Profile</span>
      </button>

      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-[#BBA767]/10 rounded-xl">
          <Bookmark className="w-6 h-6 text-[#BBA767]" />
        </div>
        <div>
          <h1 className="text-[#294713]">Saved Articles</h1>
          <p className="text-[#897684]">{articles.length} articles saved</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {articles.map((article) => (
          <div
            key={article.id}
            className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group relative"
            style={{ aspectRatio: "3/4" }}
          >
            {/* Unsave Button */}
            <button
              onClick={() => handleUnsave(article.id)}
              className="absolute top-3 right-3 z-10 p-2 bg-white/90 backdrop-blur-sm rounded-full hover:bg-red-500 hover:text-white transition-colors opacity-0 group-hover:opacity-100"
              title="Unsave article"
            >
              <BookmarkX className="w-4 h-4" />
            </button>

            <div
              onClick={() => onArticleClick(article.id)}
              className="cursor-pointer h-full flex flex-col"
            >
              <div className="relative h-[55%] overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3">
                  <span className="px-3 py-1 bg-[#BBA767] text-white rounded-full text-xs uppercase tracking-wide">
                    {article.category}
                  </span>
                </div>
              </div>

              <div className="p-5 h-[45%] flex flex-col">
                <h3 className="text-[#294713] mb-2 line-clamp-2 group-hover:text-[#7CA74B] transition-colors">
                  {article.title}
                </h3>

                <p className="text-[#897684] text-sm flex-1 line-clamp-2 mb-3">
                  {article.excerpt}
                </p>

                {/* Saved Date */}
                <div className="mb-2 text-xs text-[#897684] flex items-center gap-1">
                  <Bookmark className="w-3 h-3" />
                  <span>Saved on {article.savedDate}</span>
                </div>

                <div className="flex items-center justify-between text-xs text-[#897684]">
                  <span>{article.author}</span>
                  <span>{article.readTime}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {articles.length === 0 && (
        <div className="text-center py-20">
          <Bookmark className="w-16 h-16 text-[#897684]/30 mx-auto mb-4" />
          <p className="text-[#897684]">You haven't saved any articles yet</p>
        </div>
      )}
    </div>
  );
}
